
package Producers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class PriceCheckBehaviour extends SimpleBehaviour {

	boolean finished = false;

	public PriceCheckBehaviour(Agent a) {
		super(a);

	}

	public void action() {

		/*Decision Theory*/
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
