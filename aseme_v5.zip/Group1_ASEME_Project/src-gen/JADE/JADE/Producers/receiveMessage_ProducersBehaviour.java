
package Producers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class receiveMessage_ProducersBehaviour extends SimpleBehaviour {

	boolean finished = false;

	public receiveMessage_ProducersBehaviour(Agent a) {
		super(a);

	}

	public void action() {

		/*FIPA Message Exchange*/
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
