
package Producers;

import jade.core.Agent;

public class ProducersAgent extends Agent {

	public void setup() {
		//add behaviour
		addBehaviour(new Advertising_Producers_parallel_BuyEnergy_ProducersBehaviour(this));
	}
	protected void takeDown() {
		doDelete();
	}
}
