
package Producers;

import jade.core.Agent;
import jade.core.behaviours.Behaviour;
import jade.core.behaviours.SimpleBehaviour;

public class BuyEnergy_ProducersBehaviour extends SimpleBehaviour {

	protected boolean finished;
	Behaviour simpleOneOrMoreTimesBehaviour = null;

	public BuyEnergy_ProducersBehaviour(Agent a) {
		super(a);

		finished = false;
		simpleOneOrMoreTimesBehaviour = new receiveMessage_ProducersBehaviour(this.myAgent);
		myAgent.addBehaviour(simpleOneOrMoreTimesBehaviour);
	}

	public void action(){
 	        	if (simpleOneOrMoreTimesBehaviour.done()){
 	        		if (/*insert condition*/){
						simpleOneOrMoreTimesBehaviour = new receiveMessage_ProducersBehaviour(this.myAgent);
						myAgent.addBehaviour(simpleOneOrMoreTimesBehaviour);
					}
					else finished = true;
				}
 	        }

	public boolean done() {
		return finished;
	}

}
