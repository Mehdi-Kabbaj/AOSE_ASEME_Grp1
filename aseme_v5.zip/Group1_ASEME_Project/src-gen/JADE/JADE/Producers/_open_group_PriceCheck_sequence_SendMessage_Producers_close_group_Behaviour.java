
package Producers;

import jade.core.Agent;
import jade.core.behaviours.SequentialBehaviour;

public class _open_group_PriceCheck_sequence_SendMessage_Producers_close_group_Behaviour extends SequentialBehaviour {

	public _open_group_PriceCheck_sequence_SendMessage_Producers_close_group_Behaviour(Agent a) {
		super(a);

		addSubBehaviour(new PriceCheckBehaviour(this.myAgent));
		addSubBehaviour(new SendMessage_ProducersBehaviour(this.myAgent));

	}
}
