
package MarketPlace;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class AddTheOfferToTheTableBehaviour extends SimpleBehaviour {

	boolean finished = false;

	public AddTheOfferToTheTableBehaviour(Agent a) {
		super(a);

	}

	public void action() {

		/*List Management*/
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
