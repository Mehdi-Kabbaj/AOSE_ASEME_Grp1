
package MarketPlace;

import jade.core.Agent;

public class MarketPlaceAgent extends Agent {

	public void setup() {
		//add behaviour
		addBehaviour(new Advertising_MarketPlace_parallel_ConsultTable_MarketPlaceBehaviour(this));
	}
	protected void takeDown() {
		doDelete();
	}
}
