
package Consumers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

import jade.lang.acl.ACLMessage;

public class SendMessage_ConsumersBehaviour extends SimpleBehaviour {

	boolean finished = false;

	public SendMessage_ConsumersBehaviour(Agent a) {
		super(a);

	}

	public void action() {
		ACLMessage msg = null;
		//insert message initialization code
		myAgent.send(msg);
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
