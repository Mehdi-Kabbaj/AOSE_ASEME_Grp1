
package Consumers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;

public class ReceiveMessage_ConsumersBehaviour extends SimpleBehaviour {

	protected MessageTemplate mt = null;
	boolean finished = false;

	public ReceiveMessage_ConsumersBehaviour(Agent a) {
		super(a);

	}

	public void action() {

		ACLMessage msg = myAgent.receive(mt);
		if (msg != null) {
			//insert message handling code
			finished = true;
		} else {
			block();
		}
	}

	public boolean done() {
		return finished;
	}

}
