
package Consumers;

import jade.core.Agent;

public class ConsumersAgent extends Agent {

	public void setup() {
		//add behaviour
		addBehaviour(new ConsultTable_Consumers_parallel_BuyEnergy_ConsumersBehaviour(this));
	}
	protected void takeDown() {
		doDelete();
	}
}
