
package Consumers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

public class ChooseProducerBehaviour extends SimpleBehaviour {

	boolean finished = false;

	public ChooseProducerBehaviour(Agent a) {
		super(a);

	}

	public void action() {

		/*Decision Theory*/
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
