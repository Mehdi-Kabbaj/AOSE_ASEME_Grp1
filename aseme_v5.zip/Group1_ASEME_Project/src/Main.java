import java.util.concurrent.TimeUnit;

import consumers.ConsumersAgent;
import jade.core.Profile;
import jade.core.ProfileImpl;
import jade.core.Runtime;
import jade.core.behaviours.ParallelBehaviour;
import jade.wrapper.AgentContainer;
import jade.wrapper.AgentController;
import jade.wrapper.StaleProxyException;
import marketPlace.MarketPlaceAgent;
import producers.ProducersAgent;

public class Main {
private ConsumersAgent a;
	public static void main(String[] args) throws InterruptedException {
		Runtime runtime = Runtime.instance();
		Profile config = new ProfileImpl("localhost", 8888, null);
		config.setParameter("gui", "true");
		AgentContainer mc = runtime.createMainContainer(config);
		AgentController ac1;
		AgentController ac2;
		AgentController ac3;
		AgentController ac4;
		AgentController ac5;
		AgentController ac6;
		AgentController ac7;
		AgentController ac8;
		try{
			AgentController mp = mc.createNewAgent("Market", MarketPlaceAgent.class.getName(), null);
			AgentController pa = mc.createNewAgent("Producer", ProducersAgent.class.getName(), null);
			AgentController pa2 = mc.createNewAgent("Producer-2", ProducersAgent.class.getName(), null);
			ac1 = mc.createNewAgent("consumer1", ConsumersAgent.class.getName(), null);
			ac2 = mc.createNewAgent("consumer2", ConsumersAgent.class.getName(), null);
			ac3 = mc.createNewAgent("consumer3", ConsumersAgent.class.getName(), null);
			ac4 = mc.createNewAgent("consumer4", ConsumersAgent.class.getName(), null);
			ac5 = mc.createNewAgent("consumer5", ConsumersAgent.class.getName(), null);
			ac6 = mc.createNewAgent("consumer6", ConsumersAgent.class.getName(), null);
			ac7 = mc.createNewAgent("consumer7", ConsumersAgent.class.getName(), null);
			
			mp.start();
			pa.start();
			pa2.start();
			TimeUnit.MILLISECONDS.sleep(10000);
			ac1.start();
			ac2.start();
			/*ac3.start();
			ac4.start();
			ac5.start();*/
			TimeUnit.MILLISECONDS.sleep(25000);
			ac6.start();
			ac7.start();
		}catch(StaleProxyException e){}
		
	}

}
