
package marketPlace;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.UnreadableException;
import structures.Offer;

public class ReceiveMessage_MarketPlaceBehaviour extends SimpleBehaviour {

	protected MessageTemplate mt = null;
	boolean finished = false;
	MarketPlaceAgent mp;
	public ReceiveMessage_MarketPlaceBehaviour(Agent a) {
		super(a);
		mp =(MarketPlaceAgent) a;
	}

	public void action() {

		ACLMessage msg = myAgent.receive();
		if (msg != null) {
			
			
			try {
				if(msg.getContent().equals("Request")){
					System.out.println("Market: from Consumer: "+msg.getSender().getLocalName());
					mp.addConsumers(msg.getSender().getLocalName());
				}else{
					Offer of = (Offer) msg.getContentObject();
					mp.updateProducers(msg.getSender().getLocalName(), of);
					
					System.out.println("Market: "+ of.toString());
				}
			} catch (UnreadableException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finished = true;
		} else {
			block();
		}
	}

	public boolean done() {
		return finished;
	}

}
