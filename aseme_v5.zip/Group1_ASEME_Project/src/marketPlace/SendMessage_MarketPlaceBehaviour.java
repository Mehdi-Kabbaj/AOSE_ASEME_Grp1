
package marketPlace;

import java.io.IOException;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

import jade.lang.acl.ACLMessage;

public class SendMessage_MarketPlaceBehaviour extends SimpleBehaviour {

	boolean finished = false;

	MarketPlaceAgent mp;
	public SendMessage_MarketPlaceBehaviour(Agent a) {
		super(a);
		mp = (MarketPlaceAgent)a;
	}

	public void action() {
		if(mp.getConsumers().size()>0 && mp.getTable().size()>0){
			ACLMessage msg =  new ACLMessage(ACLMessage.INFORM);
			msg.addReceiver(new AID(mp.getConsumers().get(0), AID.ISLOCALNAME));
			System.out.println("Send :"+ mp.getConsumers().get(0));
			try {
				msg.setContentObject(mp.getTable());
				mp.send(msg);
				mp.deleteConsumers();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
