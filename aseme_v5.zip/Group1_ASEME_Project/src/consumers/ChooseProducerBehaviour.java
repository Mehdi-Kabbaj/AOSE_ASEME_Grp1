
package consumers;

import java.util.Calendar;
import java.util.Random;

import consumers.ConsumersAgent;
import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import jade.lang.acl.ACLMessage;

public class ChooseProducerBehaviour extends SimpleBehaviour {

	boolean finished = false;
	ConsumersAgent agent;
	public ChooseProducerBehaviour(ConsumersAgent a) {
		super(a);
		agent = a;
	}

	public void action() {
		//We choose a producer randomly
		/*Descision Theory*/
		//if we never had a chosen offer
		if(agent.getTable().size() > 0 && agent.getChosenOffer() == null){
			Random r = new Random();
			int choose=0;
			if(agent.getTable().size()>1){
				 choose = r.nextInt(agent.getTable().size()-1);
			}
			agent.setChosenOffer(agent.getTable().get(choose));
			System.out.println(agent.getAID().getLocalName()+" Offer chosen: "+ agent.getChosenOffer().toString());
		}
		//after a day, we can choose another producer, if we choose the same producer we don't pay the raised price
		if(Calendar.getInstance().getTimeInMillis()-agent.getTime()>10000 && agent.getChosenOffer() != null){
			Random r = new Random();
			int choose=0;
			if(agent.getTable().size()>1){
				 choose = r.nextInt(agent.getTable().size()-1);
			}//if it's a new producer, we choose the new price
			if(!agent.getTable().get(choose).getProducer().equals(agent.getChosenOffer().getProducer())){
				ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
				msg.setContent("Change");
				msg.addReceiver(new AID(agent.getChosenOffer().getProducer(), AID.ISLOCALNAME));//Send request to market place and wait for Table 
				myAgent.send(msg);
				agent.setChosenOffer(agent.getTable().get(choose));
			}
			//reset the calendar, we can choose a new producer in 24h 
			agent.setTime(Calendar.getInstance().getTimeInMillis());
			System.out.println(agent.getAID().getLocalName()+" Offer chosen is : "+ agent.getChosenOffer().toString());
		}
		
		finished = true;
	}

	public boolean done() {
		return finished;
	}
}
