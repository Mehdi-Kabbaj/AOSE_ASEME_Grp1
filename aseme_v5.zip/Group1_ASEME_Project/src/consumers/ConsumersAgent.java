
package consumers;

import java.util.ArrayList;
import java.util.Calendar;

import jade.core.Agent;
import structures.Offer;

public class ConsumersAgent extends Agent {
	
	private ArrayList<Offer> table = new ArrayList<Offer>();
	private Offer chosenOffer;
	private long time = Calendar.getInstance().getTimeInMillis();
	
	public void setup() {
		addBehaviour(new ConsultTable_Consumers_parallel_BuyEnergy_ConsumersBehaviour(this));
	}
	
	@Override
	public String toString() {
		return "ConsumersAgent [table=" + table + ", chosenOffer=" + chosenOffer + "]";
	}
	
	protected void takeDown() {
		doDelete();
	}
	
	
	//////////GETTER AND SETTERS///////////////
	public Offer getChosenOffer() {
		return chosenOffer;
	}
	public void setChosenOffer(Offer chosenOffer) {
		this.chosenOffer = chosenOffer;
	}
	public ArrayList<Offer> getTable() {
		return table;
	}
	public void setTable(ArrayList<Offer> table) {
		this.table = table;
	}

	public long getTime() {
		return time;
	}

	public void setTime(long time) {
		this.time = time;
	}
	
}
