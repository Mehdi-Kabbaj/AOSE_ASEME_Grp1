
package consumers;

import java.util.concurrent.TimeUnit;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;

import jade.lang.acl.ACLMessage;

public class SendMessage_ConsumersBehaviour extends SimpleBehaviour {

	private String marketOrProducer;
	boolean finished = false;

	public SendMessage_ConsumersBehaviour(ConsumersAgent a, String market) {
		super(a);
		marketOrProducer = market;

	}

	public void action() {
		//System.out.println("send to "+marketOrProducer);
		ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
		msg.setContent("Request");
		msg.addReceiver(new AID(marketOrProducer, AID.ISLOCALNAME));//Send request to market place and wait for Table 
		myAgent.send(msg);
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
