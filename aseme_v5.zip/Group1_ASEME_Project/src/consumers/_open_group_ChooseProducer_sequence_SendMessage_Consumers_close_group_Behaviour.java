
package consumers;

import jade.core.Agent;
import jade.core.behaviours.SequentialBehaviour;

public class _open_group_ChooseProducer_sequence_SendMessage_Consumers_close_group_Behaviour
		extends
			SequentialBehaviour {

	public _open_group_ChooseProducer_sequence_SendMessage_Consumers_close_group_Behaviour(ConsumersAgent a) {
		super(a);

		//if have already received a table from the MarketPlace, then we can choose a producer and send a message to him
		addSubBehaviour(new ChooseProducerBehaviour(a));
		if(a.getChosenOffer()!=null){
			addSubBehaviour(new SendMessage_ConsumersBehaviour(a,a.getChosenOffer().getProducer()));
		}

	}
}
