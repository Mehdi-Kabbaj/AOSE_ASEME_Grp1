
package producers;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import jade.lang.acl.ACLMessage;
import jade.lang.acl.MessageTemplate;
import jade.lang.acl.UnreadableException;

public class receiveMessage_ProducersBehaviour extends SimpleBehaviour {

	protected MessageTemplate mt = null;
	boolean finished = false;
	ProducersAgent agent;
	public receiveMessage_ProducersBehaviour(ProducersAgent a) {
		super(a);
		this.agent = a;
	}

	public void action() {
		ACLMessage msg = this.agent.receive();
	
		if (msg != null) {

			if(this.agent.checkConsumers(msg.getSender().getLocalName())){
				if(msg.getContent().toString().equals("Change")){
					agent.deleteConsumer(msg.getSender().getLocalName());
				}else{
				this.agent.addConsumers(msg.getSender().getLocalName());
					System.out.println(agent.getLocalName()+" :SIZE: "+ agent.getConsumers().size());
				}
			}

			finished = true;
		} else {
			block();
		}
	}

	public boolean done() {
		return finished;
	}

}
