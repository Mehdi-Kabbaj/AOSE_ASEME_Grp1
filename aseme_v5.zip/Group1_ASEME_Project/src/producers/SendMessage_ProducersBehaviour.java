
package producers;

import java.io.IOException;

import jade.core.AID;
import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import jade.domain.introspection.AddedBehaviour;
import jade.lang.acl.ACLMessage;

import java.util.ArrayList;
import java.util.Calendar;

public class SendMessage_ProducersBehaviour extends SimpleBehaviour {

	boolean finished = false;
	ProducersAgent pa;
	public SendMessage_ProducersBehaviour(Agent a) {
		super(a);
		pa = (ProducersAgent) a;
	}
//we send the offer to Market
	public void action() {
		if(pa.isFirsTime()){//the first time at the beginning of the program 
			ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
			msg.addReceiver(new AID("Market", AID.ISLOCALNAME));
			try {
				msg.setContentObject(pa.getOffer());
				pa.setFirsTime(false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			System.out.println(pa.getAID().getLocalName()+" : Send to Market : " + pa.getOffer().toString());
		}
		
		//after 24h (10 seconds here)
		if(Calendar.getInstance().getTimeInMillis()-pa.getTime()>10000){
			ACLMessage msg = new ACLMessage(ACLMessage.INFORM);
			msg.addReceiver(new AID("Market", AID.ISLOCALNAME));
			try {
				msg.setContentObject(pa.getOffer());
				System.out.println(pa.getAID().getLocalName()+ " : Send to Market : " + pa.getOffer().toString());
				pa.setTime(Calendar.getInstance().getTimeInMillis());
				pa.setUpdated(false);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			myAgent.send(msg);
		}
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
