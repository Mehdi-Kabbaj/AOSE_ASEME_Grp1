
package producers;

import java.util.Calendar;

import jade.core.Agent;
import jade.core.behaviours.SimpleBehaviour;
import structures.Offer;

public class PriceCheckBehaviour extends SimpleBehaviour {

	boolean finished = false;
	ProducersAgent agent;
	
	public PriceCheckBehaviour(Agent a) {
		super(a);
		agent =  (ProducersAgent) a;
	}

	public void action() {

		/*Decision Theory*/
		//check the max of consumers, rise price if there are more consumers than the limit 
		if(agent.getConsumers().size()> agent.getQuota() && agent.isUpdated()==false){//rise price if there is more consumers than the producer can manages
			System.out.println("NB consumers exeded by : "+ (agent.getConsumers().size() - agent.getQuota()));
			Offer newOffer =  agent.getOffer();
			newOffer.setPrice(newOffer.getPrice()+10);
			agent.setOffer(newOffer);
			agent.setLastTimeChanged(agent.getTime());
			agent.setUpdated(true);
			agent.setQuota(agent.getQuota()+(agent.getConsumers().size()-agent.getQuota()));
			
		}
		finished = true;
	}

	public boolean done() {
		return finished;
	}

}
